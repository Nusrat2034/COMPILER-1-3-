#include <bits/stdc++.h>
#include "2105140_SymbolInfo.h"
using namespace std;
class ScopeTable
{
    int id;
    int num_bucket;
    SymbolInfo** table;

public:
    static int totalTables;
    ScopeTable* parentScope;
    static int present_table;

    ScopeTable(int n)
    {
        num_bucket = n;
        table = new SymbolInfo*[num_bucket];

        for(int i=0; i<num_bucket; i++)
                table[i] = 0;

        id = ++totalTables;
        present_table++;
        parentScope = 0;
        cout<<"\tScopeTable# "<<id<<" created"<<endl;
    }

    ~ScopeTable()
    {
        cout<<"\tScopeTable# "<<id<<" removed"<<endl;
        for(int i=0; i<num_bucket; i++)
        {
            SymbolInfo *temp1, *temp2;
            temp1 = table[i];
            while(temp1)
            {
                temp2 = temp1;
                temp1 = temp1->next;
                delete temp2;
            }
        }

        delete[] table;
        present_table--;
    }

    SymbolInfo* LookUp(string key)
    {
        int idx = hashFunction(key,num_bucket);
        SymbolInfo* temp = table[idx];
        int position = 1;

        while(temp)
        {
            if(temp->getName() == key)
            {
                break;
            }
            else
            {
                temp = temp->next;
                position++;
            }
        }

        if(temp)
            cout<<"\t'"<<temp->getName()<<"'"<<"Found in ScopeTable# "<<id<<" at position "<<idx+1<<", "<<position<<endl;
        return temp;
    }

    bool Insert(SymbolInfo si)
    {
        int idx = hashFunction(si.getName(),num_bucket);
        SymbolInfo *temp = table[idx], *prev = 0;
        int position = 1;

        while(temp)
        {
            if(temp->getName() == si.getName())
            {
                cout<<"'\t"<<si.getName()<< "'"<<" already exists in the current ScopeTable"<<endl;
                return false;
            }
            else
            {
                prev = temp;
                temp = temp->next;
                position++;
            }
        }

        temp = new SymbolInfo(si.getName(), si.getType());

        if(prev)
            prev->next = temp;
        else table[idx] = temp;

        cout<<"\tInserted in ScopeTable# "<<id<<" at position "<<idx+1<<", "<<position<<endl;
        return true;
    }

    bool Delete(string key)
    {
        SymbolInfo* temp = LookUp(key);

        if(!temp)
        {
           cout<<"\t Not found in the current ScopeTable"<<endl;
            return false;
        }

        int idx = hashFunction(key,num_bucket);
        temp = table[idx];
        SymbolInfo* prev = 0;
        int position = 1;

        while(temp)
        {
            if(temp->getName() == key)
            {
                if(prev)
                    prev->next = temp->next;
                else
                    table[idx] = temp->next;
                delete temp;
                break;
            }
            else
            {
                prev = temp;
                temp = temp->next;
                position++;
            }
        }

        cout<<"\tDeleted entry at "<<idx+1<<", "<<position<<" from current ScopeTable"<<endl;

        return true;
    }
    void printTable(const string& prefix = "")
    {
    cout << prefix << "\tScopeTable# " << this->id << endl;
    for(int i = 0; i < num_bucket; i++)
    {
        cout <<"\t"<< prefix << i + 1 << "--> ";
        SymbolInfo* temp = table[i];
        while(temp)
        {
            cout << "<" << temp->getName() << "," << temp->getType() << "> ";
            temp = temp->next;
        }
        cout << endl;
    }
    cout << endl;
    }
};

int ScopeTable::totalTables = 0;
int ScopeTable::present_table = 0;