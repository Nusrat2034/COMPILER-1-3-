#include <bits/stdc++.h>
using namespace std;

unsigned int hashFunction(string str, unsigned int num_buckets) {
    unsigned int hash = 0;
    unsigned int len = str.length();
    for (unsigned int i = 0; i < len; i++)
    {
    hash = ((str[i]) + (hash << 6) + (hash << 16)- hash) %
    num_buckets;
    }
    return hash;
}  

class SymbolInfo {
    string name, type;

public:
    SymbolInfo* next;

    SymbolInfo()
    {
        next = 0;
    }

    SymbolInfo(string name, string type)
    {
        this->name = name;
        this->type = type;
        next = 0;
    }

    void setName(string name)
    {
        this->name = name;
    }

    void setType(string type)
    {
        this->type = type;
    }

    string getName()
    {
        return name;
    }

    string getType()
    {
        return type;
    }
};