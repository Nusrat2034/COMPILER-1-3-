#include <bits/stdc++.h>
#include"2105140_SymbolTable.h"

using namespace std;

int main(int argc, char* argv[])
{
    freopen(argv[1], "r", stdin);
    freopen(argv[2], "w", stdout);

    int size;
    cin >> size;
    SymbolTable* st = new SymbolTable(size);
    string command;
    int cmdCount = 0;

    while (cin >> command)
    {
        cmdCount++;
        cout << "Cmd " << cmdCount << ": " << command;

        if (command == "I")
        {
            string name, type;
            cin >> name >> type;
            string restOfLine;
            getline(cin, restOfLine);
            cout << " " << name << " " << type << restOfLine << endl;

            if (type == "STRUCT" || type == "UNION")
            {
                stringstream ss(restOfLine);
                string pairType, pairName;
                vector<pair<string, string>> fields;

                while (ss >> pairType >> pairName)
                {
                    fields.emplace_back(pairType, pairName);
                }

                stringstream finalType;
                finalType << type << ",{";
                for (size_t i = 0; i < fields.size(); ++i)
                {
                    if (i > 0) finalType << ",";
                    finalType << "(" << fields[i].first << "," << fields[i].second << ")";
                }
                finalType << "}";

                st->Insert(SymbolInfo(name, finalType.str()));
            }
            else if (type == "FUNCTION")
            {
                string returnType, token;
                stringstream ss(restOfLine);
                ss >> returnType; 

                vector<string> params;
                while (ss >> token)
                {
                    params.push_back(token);
                }

                stringstream finalType;
                finalType << type << "," << returnType << "<==(";
                for (size_t i = 0; i < params.size(); ++i)
                {
                    if (i > 0) finalType << ",";
                    finalType << params[i];
                }
                finalType << ")>";

                st->Insert(SymbolInfo(name, finalType.str()));
            }
            else
            {
                st->Insert(SymbolInfo(name, type));
            }
        }
        else if (command == "L")
        {
            string name;
            vector<string> params;
            string temp;
            getline(cin, temp);
            stringstream ss(temp);
            while (ss >> name)
                params.push_back(name);

            if (params.size() != 1)
            {
                cout << " ";
                for (auto& p : params) cout << p << " ";
                cout << endl;
                cout << "\tNumber of parameters mismatch for the command L" << endl;
            }
            else
            {
                cout << " " << params[0] << endl;
                SymbolInfo* result = st->LookUp(params[0]);
                if (result)
                {

                }
                else
                {
                    cout << "\t'" << params[0] << "' not found in any of the ScopeTables" << endl;
                }
            }
        }
        else if (command == "D")
        {
            string name;
            vector<string> params;
            string temp;
            getline(cin, temp);
            stringstream ss(temp);
            while (ss >> name)
                params.push_back(name);

            if (params.size() != 1)
            {
                if (!params.empty()) {
                    cout << " ";
                    for (auto& p : params) cout << p << " ";
                }
                cout << endl;
                cout << "\tNumber of parameters mismatch for the command D" << endl;
            }
            else
            {
                cout << " " << params[0] << endl;
                st->Remove(params[0]);
            }
        }
        else if (command == "P")
        {
            string type;
            cin >> type;
            cout << " " << type << endl;
            if (type == "A")
                st->printAll();
            else if (type == "C")
                st->printCurrent();
        }
        else if (command == "S")
        {
            cout << endl;
            st->enterScope();
        }
        else if (command == "E")
        {
            cout << endl;
            st->exitScope();
        }
        else if (command == "Q") {
            cout << endl;
            while (ScopeTable::present_table > 0) {
                st->exitScope();
            }
            return 0;
        }
        
        else
        {
         cout<<"Invalid command"<<endl;
        }
    }
}
