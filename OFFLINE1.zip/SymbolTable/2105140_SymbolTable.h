#include <bits/stdc++.h>
#include"2105140_ScopeTable.h"

using namespace std;

class SymbolTable {
    ScopeTable* currentScope;
    int scopeTableSize;

public:
    SymbolTable(int n)
    {
        scopeTableSize = n;
        currentScope = new ScopeTable(scopeTableSize);
    }

    void enterScope()
    {
        ScopeTable* temp = new ScopeTable(scopeTableSize);
        temp->parentScope = currentScope;
        currentScope = temp;
    }

    void exitScope()
    {
        if(currentScope)
        {
            ScopeTable* temp = currentScope;
            currentScope = currentScope->parentScope;
            delete temp;
        }
        else
        {
            cout<<"No Scope Exists"<<endl;
        }
    }

    bool Insert(SymbolInfo si)
    {
        return currentScope->Insert(si);
    }

    bool Remove(string key)
    {
        return currentScope->Delete(key);
    }

    SymbolInfo* LookUp(string key)
    {
        SymbolInfo* result = 0;
        ScopeTable* temp = currentScope;

        while(result == 0 && temp != 0)
        {
            result = temp->LookUp(key);
            temp = temp->parentScope;
        }

        return result;
    }

    void printCurrent()
    {
        currentScope->printTable();
    }

    void printAll()
   {
    ScopeTable* current = currentScope;
    int level = 0;
    while(current != nullptr)
    {
        string indent(level * 6, ' ');
        current->printTable(indent);
        current = current->parentScope;
        level++;
    }
}

};
